from pathlib import Path
import hashlib
import json
import os
import shutil
import tempfile
import unittest

import audit_evidence as ae

HERE = Path(__file__).resolve().parent
MATRIX = HERE / 'audit-fixtures/matrix'


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory(prefix='evidence-audit-')
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        # Copy the two real already-executed qualification outputs, not a fake
        # implementation-shaped success fixture. No test workload is rerun.
        self.matrix = self.root / 'matrix'
        self.matrix.mkdir()
        for name in ['results.jsonl', 'member2-resync-write-matrix.mjs']:
            shutil.copyfile(MATRIX / name, self.matrix / name)
        (self.matrix / 'source-pin').mkdir()
        self.receipt = self.matrix / 'source-pin/receipt.json'
        shutil.copyfile(MATRIX / 'source-pin/receipt.json', self.receipt)
        self.native = self.root / 'native'
        shutil.copytree(HERE / 'audit-fixtures/native', self.native)

    def matrix_rows(self):
        return [json.loads(s) for s in (self.matrix / 'results.jsonl').read_text().splitlines()]

    def write_matrix(self, rows):
        data = ('\n'.join(json.dumps(r) for r in rows) + '\n').encode()
        (self.matrix / 'results.jsonl').write_bytes(data)
        receipt = json.loads(self.receipt.read_text())
        receipt['results_sha256'] = hashlib.sha256(data).hexdigest()
        self.receipt.write_text(json.dumps(receipt))

    def edit_native_log(self, transform):
        path = self.native / 'full.log'
        data = transform(path.read_text()).encode()
        path.write_bytes(data)
        receipt_path = self.native / 'receipt.json'
        receipt = json.loads(receipt_path.read_text())
        receipt['log_sha256'] = hashlib.sha256(data).hexdigest()
        receipt['log_bytes'] = len(data)
        receipt_path.write_text(json.dumps(receipt))

    def test_both_real_receipts_pass_and_preserve_unbounded_warning(self):
        self.assertEqual(ae.audit(self.root, self.receipt)['pending_passed'], 7)
        result = ae.audit(self.root, self.native / 'receipt.json')
        self.assertTrue(result['artifact_consistency'])
        self.assertFalse(result['reported_whole_recovery_bounded'])
        self.assertTrue(result['reported_final_unbounded_audit_required'])

    def test_changed_artifact_is_rejected(self):
        with (self.matrix / 'results.jsonl').open('a') as handle:
            handle.write('\n')
        with self.assertRaisesRegex(ValueError, 'hash mismatch'):
            ae.audit(self.root, self.receipt)

    def test_green_summary_cannot_hide_failed_cold_proof_even_with_new_hash(self):
        rows = self.matrix_rows()
        rows[0]['coldProofs']['invalidMessageIds'] = ['new']
        self.write_matrix(rows)
        with self.assertRaisesRegex(ValueError, 'invalid coldProofs'):
            ae.audit(self.root, self.receipt)

    def test_duplicate_case_cannot_stand_in_for_missing_case(self):
        rows = self.matrix_rows()
        rows[1] = rows[0]
        self.write_matrix(rows)
        with self.assertRaisesRegex(ValueError, 'Duplicate or unexpected'):
            ae.audit(self.root, self.receipt)

    def test_missing_required_error_field_is_not_silently_none(self):
        rows = self.matrix_rows()
        del rows[0]['coldAuditError']
        self.write_matrix(rows)
        with self.assertRaisesRegex(ValueError, 'missing or failed coldAuditError'):
            ae.audit(self.root, self.receipt)

    def test_native_source_mismatch_rejected_despite_rehashed_log(self):
        self.edit_native_log(lambda s: s.replace('8e65a6e73ae191ffa7fc89c2e88fa382ad2ac000', 'a' * 40))
        with self.assertRaisesRegex(ValueError, 'source mismatch'):
            ae.audit(self.root, self.native / 'receipt.json')

    def test_truncated_native_log_cannot_pass_on_exit_receipt(self):
        self.edit_native_log(lambda s: s[:s.index('ℹ tests')])
        with self.assertRaisesRegex(ValueError, 'terminal summary'):
            ae.audit(self.root, self.native / 'receipt.json')

    def test_external_path_and_symlink_refused(self):
        with self.assertRaisesRegex(ValueError, 'escapes'):
            ae.read_inside(self.root, HERE / 'native-8e65-full.log')
        original = self.native / 'full.log'
        target = self.root / 'saved.log'
        original.rename(target)
        original.symlink_to(target)
        with self.assertRaisesRegex(ValueError, 'Symlink'):
            ae.audit(self.root, self.native / 'receipt.json')

    def test_fifo_refused_without_waiting_for_a_writer(self):
        path = self.root / 'fifo'
        os.mkfifo(path)
        with self.assertRaisesRegex(ValueError, 'regular file'):
            ae.read_inside(self.root, path)

    def test_duplicate_json_keys_refused(self):
        with self.assertRaisesRegex(ValueError, 'Duplicate JSON field'):
            ae.strict_json('{"exit_code":1,"exit_code":0}')


if __name__ == '__main__':
    unittest.main(verbosity=2)
