# Local workbench

Useful, finite work on this laptop without a hosted room, model subscription,
second laptop, background service, or schedule. Python 3.12+, standard library.
This is separate from Project Room runtime implementation and deployment.

The three fixed workloads produce:

- **Inventory:** file hashes, line counts, TODO/FIXME counts, and lexical import
  candidates. Import matches are hints, not a JavaScript dependency parser.
- **Compression:** reusable gzip-1, gzip-9, and LZMA-1 source bundles, each
  decompressed and compared with the exact original bytes before success.
- **Search:** SQLite FTS5 indexes containing the selected source, tested with
  index integrity checks and known-document queries. Search works offline.

## Start

From the containing `project room` folder:

```sh
./local-lab/lab plan /absolute/path/to/source /absolute/path/to/new-capsule \
  --max-files 800 --max-mib 20 --batch-files 32
./local-lab/lab run /absolute/path/to/new-capsule /absolute/path/to/new-run \
  --workers 4 --timeout 30 --rss-mib 512
./local-lab/lab search /absolute/path/to/new-run 'restore AND privacy'
./local-lab/lab verify /absolute/path/to/new-run
```

The launcher uses the existing Codex Python when present. Set
`LOCAL_LAB_PYTHON=/path/to/python3` on another machine. No installation is needed.
All commands print JSON. Nonzero exit means refusal, failure, or cancellation;
inspect the saved journal and per-attempt logs rather than assuming completion.

An immediately usable source index is in
`runs/server-ready/`. For example:

```sh
./local-lab/lab search local-lab/runs/server-ready \
  'restore AND privacy' --limit 5
```

Results are sorted by path. FTS scores from separate index shards are not
represented as a global relevance ranking. FTS syntax errors are reported.
`complete` reports whether all expected search shards have finished. `verify`
refuses an absent or unfinished run and never creates a new journal.

## Repeatable experiments

```sh
./local-lab/lab bench /absolute/path/to/capsule /absolute/path/to/new-experiment \
  --workers 1,2,4,8 --trials 2
```

Each sample runs identical content-addressed jobs in a fresh journal. Trial
order alternates to reduce order effects. A logical digest must agree across
all samples; timings and physical SQLite file layout are excluded from that
comparison. Compression artifact hashes and round-trip checks are retained.

Wall time includes startup and monitoring. Separate fields record worker body
CPU, parent CPU, and reaped child CPU including interpreter startup and monitor
processes. Do not confuse these with package energy or whole-device utilization.
These short, warm-cache samples are exploratory, not controlled hardware tests.
`benchmark-runner.py` freezes the version used for the timing matrix. Use
`workbench.py` (through `lab`) for new work: it also includes the later
verification-completeness and pre-launch attempt-reservation fixes.

## Interrupt and resume

Ctrl-C or SIGTERM stops owned workers and leaves unfinished jobs retryable.
Run the same `run` command again. Completed results and every artifact are
checked before reuse; changed inputs or artifacts fail closed. Attempts have
separate directories, so failed logs remain inspectable.
Attempts are reserved before process launch, and an orphaned directory is never
overwritten. A failed spawn can be retried in a new attempt.

A worker inherits the supervisor lock. If the supervisor is killed, a new
supervisor refuses to overlap the still-live worker. Wait for its finite job to
exit before resuming. A manually SIGSTOPped worker needs to be resumed/stopped
by its owner; a wall deadline cannot be enforced by a dead supervisor.

The journal is **single-host** SQLite WAL. Do not share it as a network queue.
Copy a stopped capsule/run for inspection, or give another host its own run
directory. A capsule contains selected file objects, an immutable plan, and the
exact `tool.py`. Reproduce an older capsule after updating the main tool with:

```sh
python3 /path/to/capsule/tool.py run /path/to/capsule /path/to/new-run
```

No transfer or second-host execution is implied by preparing a capsule.

## Resource and input limits

- Explicit source root; no network requests or arbitrary shell/job commands.
- Up to 256 KiB per text file, UTF-8 only; hidden directories, symlinks,
  dependencies, build products, old archives and audit/evidence folders skipped.
- Default 320 files / 16 MiB, at most 5,000 files / 128 MiB. Selection is a
  deterministic, sorted prefix, not a representative sample or whole-repo audit.
- Worker groups have wall deadlines, OS CPU/file-size limits, and sampled RSS
  checks. The RSS threshold may be overshot between samples; it is not a hard
  memory sandbox. Fixed workers retain the ordinary user's filesystem rights.
- Worker logs are drained and capped at 1 MiB. Saved results/artifacts are hashed.
- The input-selection rules are not a secret detector. Point it only at a source
  tree you intend to copy into the local capsule. Nothing uploads automatically.

The tool leaves the laptop's other applications, network settings, power
settings, and other agents' processes alone. More workers are useful only when
the experiment demonstrates a benefit; no persistent CPU-filling loop exists.

## Verification and research

```sh
"$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3" \
  local-lab/test_workbench.py
```

The tests exercise actual subprocess cancellation, supervisor death with a live
worker, lock inheritance, timeout/resume, snapshot isolation from source edits,
symlink/hidden-directory exclusion, cache reuse, and corrupt-input/result refusal.
They also cover failed process launch and an orphaned attempt directory.
The short-worker RSS race has a deterministic regression using real subprocesses:
completion during memory sampling is reaped and its result verified normally;
missing RSS while an owned worker remains live still fails closed. The current
suite has ten tests. Earlier immutable capsules retain their original tool;
use each capsule's `tool.py` when reproducing its saved results.

Design references: [Python subprocess](https://docs.python.org/3.12/library/subprocess.html),
[resource limits](https://docs.python.org/3.12/library/resource.html),
[file locking](https://docs.python.org/3.12/library/fcntl.html),
[SQLite FTS5](https://sqlite.org/fts5.html),
[SQLite WAL limitations](https://sqlite.org/wal.html).
